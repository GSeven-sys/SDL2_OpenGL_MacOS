#include<iostream>
#include"opengl_demo.h"

Shader* shader_1 = nullptr;
Texture* texture_1 = nullptr;
GLuint program_1=0;
GLuint posVbo_1,vao_1,uvVbo_1;
float vertices_1[]{
    -0.5f,-0.5f,0.0f,
    0.5f,-0.5f,0.0f,
    -0.5f,0.5f,0.0f
};
float uvs_1[]{
    0.0f,0.0f,
    1.0f,0.0f,
    0.0f,1.0f
};

void simple_opengl(){
    Shader* shader_1=new Shader("assets/shaders/vertex_demo.glsl","assets/shaders/fragment_demo.glsl");

    glGenBuffers(1,&posVbo_1);
    glBindBuffer(GL_ARRAY_BUFFER,posVbo_1);
    glBufferData(GL_ARRAY_BUFFER,sizeof(vertices_1),vertices_1,GL_STATIC_DRAW);

    glGenBuffers(1,&uvVbo_1);
    glBindBuffer(GL_ARRAY_BUFFER,uvVbo_1);
    glBufferData(GL_ARRAY_BUFFER,sizeof(uvs_1),uvs_1,GL_STATIC_DRAW);

    //获取属性存储位置
    GLuint posLocation_1=glGetAttribLocation(shader_1->mProgram,"aPos");
    GLuint uvLocation_1=glGetAttribLocation(shader_1->mProgram,"aUV");
    //创建vao
    glGenVertexArrays(1,&vao_1);
    glBindVertexArray(vao_1);
    //传入位置属性描述数据
    glBindBuffer(GL_ARRAY_BUFFER,posVbo_1);     //绑定posVbo_1,接下来的属性描述和这个buffer有关
    glEnableVertexAttribArray(posLocation_1);
    glVertexAttribPointer(posLocation_1,3,GL_FLOAT,GL_FALSE,3*sizeof(float),(void*)0);
    //传入uv属性描述数据
    glBindBuffer(GL_ARRAY_BUFFER,uvVbo_1);      //再绑定uvVbo_1
    glEnableVertexAttribArray(uvLocation_1);
    glVertexAttribPointer(uvLocation_1,2,GL_FLOAT,GL_FALSE,2*sizeof(float),(void*)0);

    Texture* texture_1=new Texture("assets/textures/dafeng.png",0);
}

void render_demo(){
    glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);

    shader_1->begin();
    //返回图片宽高
    shader_1->setFloat("width",texture_1->getWidth());
    shader_1->setFloat("height",texture_1->getHeight());
    //设置采样器
    shader_1->setInt("sampler",0);

    //发送绘制指令
    glDrawArrays(GL_TRIANGLES,0,3);

    shader_1->end();
    SDL_Delay(33);
}

void del_gl(){
    delete texture_1;
    glDeleteProgram(program_1);
    glDeleteBuffers(1,&posVbo_1);
    //销毁VAO
    glDeleteVertexArrays(1,&vao_1);
    glDeleteBuffers(1,&uvVbo_1);
}