#include"test.h"

#define STB_IMAGE_IMPLEMENTATION
#include"stb_image.h"

//创建一个Program壳子
GLuint program=0;
Texture* texture=nullptr;
Texture* heisiTexture=nullptr;
Texture* heiTexture=nullptr;
Texture* noiseTexture=nullptr;

//n:创建的vbo的数量
//target:把当前的vbo绑定到状态机的哪个插槽
//buffer：绑定的vbo编号；0表示不绑定任何buffer
//size:装入当前buffer的数据大小
//data：装有数据的数组指针
//usage：当前buffer的用法：
//       GL_STATIC_DRAW:vbo模型数据不会频繁改变
//       GL_DYNAMIC_DRAW:vbo模型数据会频繁改变
void prepare_vbo(GLsizei n,GLuint *buffer,GLenum target,const void *data,size_t size,GLenum usage){
   //创建VBO
   glGenBuffers(n,buffer);
   //绑定当前vbo，到opengl状态机的当前vbo插槽上
   glBindBuffer(target,*buffer);
   //当前vbo传输数据，也是在开辟显存
   glBufferData(target,size,data,usage);
}

//VAO（Veretex Array Object）：顶点数组对象，用于存储一个Mesh网格所有的顶点属性描述信息
//位置数据：每个顶点3个数字，每个数字都是float类型（4byte）

//VAO的创建：glGenVertexArrays(GLsizei n,GLuint *arrays)
//          n:创建多少个vao
//          arrays:创建出来的vao编号们，都放在arrays指向的数组中

//VAO的绑定：glBindVertexArray(GLuint array)
//          array:要绑定的vao编号

//VAO加入描述属性：glVertexAttribPointer(GLuint index,GLint size,GLenum type,GLboolean normalized,GLsizei stride,const void *pointer)
//                index：要描述第几个属性
//                size：这个属性包含几个数字
//                type：这个属性每个数字是什么数据类型
//                normalized：是否归一化（暂时不用）
//                stride：每个顶点数据的步长
//                pointer：这个属性在每个顶点数据内的偏移量

//VAO的删除：glDeleteVertexArrays(GLsizei n,GLuint *arrays)
//          n：删除多少个vao
//          arrays：要删除的vao存放数组
void prepare_vao(GLsizei n,GLuint *arrays){
   glGenVertexArrays(n,arrays);
   glBindVertexArray(*arrays);

   //动态获取位置
   //GLuint posLocation=glGetAttribLocation(shader->mProgram,"aPos");
   //GLuint colorLocation=glGetAttribLocation(shader->mProgram,"aColor");

   //位置属性放在vao属性的0号位置，要先激活
   //glEnableVertexAttribArray(posLocation);
   //位置属性描述
   //glVertexAttribPointer(posLocation,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)0);
   //颜色属性放在vao属性的1号位置，要先激活
   //glEnableVertexAttribArray(colorLocation);
   //颜色属性描述
   //glVertexAttribPointer(colorLocation,3,GL_FLOAT,GL_FALSE,6*sizeof(float),(void*)(3*sizeof(float)));
}

void prepare_attrib(std::string attribute,GLint size,GLsizei stride,const void *pointer){
   //动态获取位置
   GLuint Location=glGetAttribLocation(shader->mProgram,attribute.c_str());
   //属性放在vao属性的Location位置，要先激活
   glEnableVertexAttribArray(Location);
   //属性描述
   glVertexAttribPointer(Location,size,GL_FLOAT,GL_FALSE,stride,pointer);
}

void prepare_Shader(){
   shader=new Shader("assets/shaders/vertex.glsl","assets/shaders/fragment.glsl");
   shaderLight=new Shader("assets/shaders/light_cube.vs","assets/shaders/light_cube.fs");
}

void prepareTexture(){
   //创建纹理并绑定到0号纹理单元
   texture=new Texture("assets/textures/shatou.jpg",0);

   // heisiTexture=new Texture("assets/textures/heisi.png",1);
   // heiTexture=new Texture("assets/textures/hei.jpg",2);
   // noiseTexture=new Texture("assets/textures/mc1.png",3);
}

void prepare_ebo(GLsizei n,GLuint *buffer,GLenum target,const void *data,size_t size,GLenum usage){
   glGenBuffers(n,buffer);
   glBindBuffer(target,*buffer);
   glBufferData(target,size,data,GL_STATIC_DRAW);
}