#pragma once
#include<string>

#include"core.h"

class Shader{
public:
    Shader(const char* vertexPath,const char*fragmentPath);
    ~Shader();
    void begin();//开始使用当前的Shader
    void end();//结束使用当前的Shader
    void setFloat(const std::string& name,float value);
    void setVector3(const std::string& name,float x,float y,float z);
    void setVector3(const std::string& name,float* values);
    void setVector3(const std::string& name,glm::vec3 value);
    void setInt(const std::string& name,int value);
    void setMatrix4x4(const std::string& name,glm::mat4 value);
private:
    //shader program
    //type:COMPILE LINK
    void checkShaderErrors(GLuint target,std::string type);

public:
    GLuint mProgram{0};
};