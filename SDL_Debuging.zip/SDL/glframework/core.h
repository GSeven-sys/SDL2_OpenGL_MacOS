#pragma once

#include<GL/glew.h>
#include<Cocoa/Cocoa.h>
#include<SDL2/SDL.h>
//#include<SDL2/SDL_opengl.h>
//GLM
#include<glm/glm.hpp>
#include<glm/gtc/matrix_transform.hpp>
#include<glm/gtc/type_ptr.hpp>

#define GLM_ENABLE_EXPERIMENTAL
#include<glm/gtx/string_cast.hpp>