#include"core.h"
#include"stb_image.h"
#include"shader.h"
#include"texture.h"

void simple_opengl();

void render_demo();

void del_gl();