#pragma once

#include<iostream>
#include<chrono>
#include<cmath>

#include"core.h"
#include"shader.h"
#include"texture.h"

extern Shader* shader;
extern Shader* shaderLight;
extern GLuint program;
extern Texture* texture;

void prepare_vbo(GLsizei n,GLuint *buffer,GLenum target,const void *data,size_t size,GLenum usage);
void prepare_vao(GLsizei n,GLuint *arrays);
void prepare_attrib(std::string attribute,GLint size,GLsizei stride,const void *pointer);

void prepare_Shader();

void render();

void prepare_ebo(GLsizei n,GLuint *buffer,GLenum target,const void *data,size_t size,GLenum usage);

void prepareTexture();