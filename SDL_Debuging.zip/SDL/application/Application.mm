#include"Application.h"

void Application::mouseCallback(double xposIn,double yposIn){
    float xpos=static_cast<float>(xposIn);
    float ypos=static_cast<float>(yposIn);
    //如果是第一帧，（上一帧）鼠标位置设置为当前帧位置
    if(firstMouse){
        lastX=xpos;
        lastY=ypos;
        firstMouse=false;
    }
    //计算上一帧和当前帧的偏移量
    float xoffset=xpos-lastX;
    float yoffset=lastY-ypos;       //Y坐标从底部往顶部增大，所以相减顺序相反
    lastX=xpos;
    lastY=ypos;

    float sensitivity=0.1f;         //设置灵明度
    yoffset*=sensitivity;
    xoffset*=sensitivity;

    yaw+=xoffset;
    pitch+=yoffset;

    if(pitch>89.0f)
        pitch=89.0f;
    if(pitch<-89.0f)
        pitch=-89.0f;
    
    glm::vec3 front;
    front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
    front.y = sin(glm::radians(pitch));
    front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
    cameraFront = glm::normalize(front);
}