#pragma once
#include"core.h"

class Application{
private:
    bool firstMouse = true;
    float yaw   = -90.0f;
    float pitch =  0.0f;
    float lastX =  640.0f / 2.0f;
    float lastY =  480.0f / 2.0f;
    float fov   =  45.0f;
public:
    void mouseCallback(double xposIn,double yposIn);
    glm::vec3 cameraFront;
};