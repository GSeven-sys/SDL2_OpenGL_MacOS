#include"camera.h"

Camera::Camera(){

}

Camera::~Camera(){

}

glm::mat4 Camera::getViewMatrix(){
    glm::vec3 cameraFront=glm::cross(cameraUp,cameraRight);
    glm::vec3 cameraTarget=cameraPos+cameraFront;

    return glm::lookAt(cameraPos,cameraTarget,cameraUp);
}

glm::mat4 Camera::getProjectionMatrix(){
    return glm::identity<glm::mat4>();
}

//正交投影
OrthographicCamera::OrthographicCamera(float left,float right,float top,float bottom,float near,float far){
    mLeft=left;
    mRight=right;
    mTop=top;
    mBottom=bottom;
    mNear=near;
    mFar=far;
}

OrthographicCamera::~OrthographicCamera(){

}

glm::mat4 OrthographicCamera::getProjectionMatrix(){
    return glm::ortho(mLeft,mRight,mTop,mBottom,mNear,mFar);
}

//透视投影
PerspectiveCamera::PerspectiveCamera(float fovy,float aspect,float near,float far){
    mFovy=fovy;
    mAspect=aspect;
    mNear=near;
    mFar=far;
}

PerspectiveCamera::~PerspectiveCamera(){

}

glm::mat4 PerspectiveCamera::getProjectionMatrix(){
    return glm::perspective(glm::radians(mFovy),mAspect,mNear,mFar);
}