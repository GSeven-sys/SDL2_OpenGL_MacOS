#include"test.h"
#include"camera.h"
#include"Application.h"
#include"opengl_demo.h"

GLuint vbo,vao,ebo,uvVbo,lightVAO,lightVBO;
glm::mat4 transform(1.0f);
glm::mat4 perspectiveMatrix(1.0f);
glm::mat4 viewMatrix(1.0f);
glm::vec3 lightPos(-1.0f,-1.0f,1.0f);
glm::mat4 model =glm::mat4(1.0f);

//GLuint texture;
Shader* shader=nullptr;
Shader* shaderLight=nullptr;

Uint64 start=SDL_GetPerformanceCounter()/SDL_GetPerformanceFrequency();

float vertices[] = {
   //position             //uv         //Normal Vector
    -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,  0.0f,  0.0f, -1.0f,
     0.5f, -0.5f, -0.5f,  1.0f, 0.0f,  0.0f,  0.0f, -1.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,  0.0f,  0.0f, -1.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,  0.0f,  0.0f, -1.0f,
    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,  0.0f,  0.0f, -1.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,  0.0f,  0.0f, -1.0f,

    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,  0.0f,  0.0f,  1.0f, 
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,  0.0f,  0.0f,  1.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 1.0f,  0.0f,  0.0f,  1.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 1.0f,  0.0f,  0.0f,  1.0f,
    -0.5f,  0.5f,  0.5f,  0.0f, 1.0f,  0.0f,  0.0f,  1.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,  0.0f,  0.0f,  1.0f,

    -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,  -1.0f,  0.0f,  0.0f,
    -0.5f,  0.5f, -0.5f,  1.0f, 1.0f,  -1.0f,  0.0f,  0.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,  -1.0f,  0.0f,  0.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,  -1.0f,  0.0f,  0.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,  -1.0f,  0.0f,  0.0f,
    -0.5f,  0.5f,  0.5f,  1.0f, 0.0f,  -1.0f,  0.0f,  0.0f,

     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,  1.0f,  0.0f,  0.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,  1.0f,  0.0f,  0.0f,
     0.5f, -0.5f, -0.5f,  0.0f, 1.0f,  1.0f,  0.0f,  0.0f,
     0.5f, -0.5f, -0.5f,  0.0f, 1.0f,  1.0f,  0.0f,  0.0f,
     0.5f, -0.5f,  0.5f,  0.0f, 0.0f,  1.0f,  0.0f,  0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,  1.0f,  0.0f,  0.0f,

    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,  0.0f, -1.0f,  0.0f,
     0.5f, -0.5f, -0.5f,  1.0f, 1.0f,  0.0f, -1.0f,  0.0f,
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,  0.0f, -1.0f,  0.0f,
     0.5f, -0.5f,  0.5f,  1.0f, 0.0f,  0.0f, -1.0f,  0.0f,
    -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,  0.0f, -1.0f,  0.0f,
    -0.5f, -0.5f, -0.5f,  0.0f, 1.0f,  0.0f, -1.0f,  0.0f,

    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,  0.0f,  1.0f,  0.0f,
     0.5f,  0.5f, -0.5f,  1.0f, 1.0f,  0.0f,  1.0f,  0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,  0.0f,  1.0f,  0.0f,
     0.5f,  0.5f,  0.5f,  1.0f, 0.0f,  0.0f,  1.0f,  0.0f,
    -0.5f,  0.5f,  0.5f,  0.0f, 0.0f,  0.0f,  1.0f,  0.0f,
    -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,  0.0f,  1.0f,  0.0f
};

/* unsigned int indices[]{
      0,1,2,3
}; */

float uvs[]={
   0.0f,0.0f,
   1.0f,0.0f,
   1.0f,1.0f,
   0.0f,1.0f
};

void preparePerspective(){
   //fovy:y轴方向的视张角
   //aspect：近平面的横纵百分比
   //near：近平面距离
   //far：远平面距离
   perspectiveMatrix=glm::perspective(glm::radians(60.0f),640.0f/480.0f,0.1f,1000.0f);
}

void prepareCamera(){
   //lookAt:生成一个viewMatrix
   //eye:当前摄像机所在的位置
   //center：当前摄像机看向的那个点
   //up:上向量
   viewMatrix=glm::lookAt(glm::vec3(0.0f,0.0f,3.0f),glm::vec3(0.0f,0.0f,0.0f),glm::vec3(0.0f,1.0f,0.0f));
}

void doRotationTransform(){
   //构建一个旋转矩阵，绕着z轴旋转45度
   //rotate函数：用于生成旋转矩阵
   //bug1：rotate必须得到一个float类型的角度
   //bug2：rotate函数接受的不是角度（degree），接受的弧度（radians）
   //注意点：radians函数也是模板函数,要传入float类型
   transform=glm::rotate(glm::mat4(1.0f),45.0f,glm::vec3(0.0f,0.0f,1.0f));
}
//平移变换
void doTranslationTransform(){
   transform=glm::translate(glm::mat4(1.0f),glm::vec3(1.0f,0.0f,0.0f));
}
//缩放变换
void doScaleTransform(){
   transform=glm::scale(glm::mat4(1.0f),glm::vec3(0.1f,0.5f,1.0f));
}
void preTransform(){
   //先平移再叠加旋转
   //transform=glm::translate(transform,glm::vec3(0.01f,0.0f,0.0f));
   //先旋转
   //transform=glm::rotate(transform,glm::radians(45.0f),glm::vec3(0.0f,0.0f,1.0f));
   //先缩放
   transform=glm::scale(transform,glm::vec3(0.1f,1.0f,1.0f));
}
void doTransform(){
   float angle=1.0f;
   //transform=glm::rotate(transform,glm::radians(angle),glm::vec3(0.0f,0.0f,1.0f));

   //先平移再叠加旋转
   //transform=glm::translate(transform,glm::vec3(0.01f,0.0f,0.0f));
   //transform=glm::rotate(transform,glm::radians(angle),glm::vec3(0.0f,0.0f,1.0f));

   //再叠加平移
   //preTransform里先做一个旋转
   //transform=glm::translate(transform,glm::vec3(0.01f,0.0f,0.0f));

   //先缩放再叠加平移
   //preTransform里现做一个缩放
   transform=glm::translate(transform,glm::vec3(0.01f,0.0f,0.0f));
}

float angle=0.0f;
void doRotation(){
   angle+=2.0f;
   //每一帧都会重新构建一个旋转矩阵
   model=glm::rotate(glm::mat4(1.0f),glm::radians(angle),glm::vec3(1.0f,1.0f,0.0f));
}

//glDrawArrays(GLenum mode,GLint first,GLsizei count)
//mode:决定了对于输入的几何顶点，如何相连为三角形或直线
//     GL_TRIANGLES：没三个顶点构成一个三角形，不足三个则忽略
//     GL_TRIANGLE_STRIP：①如果末尾点序号n为偶数，则链接规则为：[n-2 n-1 n]
//     GL_TRIANGLE_FAN：绘制为扇形序列，以v0为起点
//     GL_LINES：每两个顶点构成一个直线
//     GL_LINE_STRIP：相邻点构成一条直线
void render(){
   //执行opengl画布清理操作
   glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
   //绑定当前的program
   shader->begin();
   //返回图片宽高
   shader->setFloat("width",texture->getWidth());
   shader->setFloat("height",texture->getHeight());
   //采样器
   shader->setInt("sampler",0);
   //变换矩阵
   shader->setMatrix4x4("transform",model);
   //摄像机
   shader->setMatrix4x4("viewMatrix",viewMatrix);
   //透视投影
   shader->setMatrix4x4("perspective",perspectiveMatrix);
   //时间值
   Uint64 time=SDL_GetPerformanceCounter()/SDL_GetPerformanceFrequency()-start;
   shader->setFloat("time",time);
   //速度值
   shader->setFloat("speed",3);

   float color[]={0.9,0.3,0.25};
   shader->setVector3("uColor",color);
   shader->setVector3("objectColor",1.0f, 0.5f, 0.31f);
   shader->setVector3("lightColor",1.0f,1.0f,1.0f);
   //灯光位置
   shader->setVector3("lightPos",lightPos);
   glBindVertexArray(vao);
   glDrawArrays(GL_TRIANGLES,0,36);
   //glDrawElements(GL_TRIANGLES,36,GL_UNSIGNED_INT,0);
   shader->end();

   //lightCube
   shaderLight->begin();
   model = glm::translate(model,lightPos);
   shaderLight->setMatrix4x4("model", model);
   //shaderLight->setMatrix4x4("model",transform*glm::translate(glm::mat4(1.0f),glm::vec3(2.0f,0.0f,-2.0f)));
   shaderLight->setMatrix4x4("view",viewMatrix);
   shaderLight->setMatrix4x4("projection",perspectiveMatrix);
   glBindVertexArray(lightVAO);
   glDrawArrays(GL_TRIANGLES,0,36);
   shaderLight->end();
   //延时33毫秒
   SDL_Delay(33);
}

void light_demo(){
   prepare_vao(1,&lightVAO);
   glBindVertexArray(lightVAO);
   prepare_vbo(1,&lightVBO,GL_ARRAY_BUFFER,vertices,sizeof(vertices),GL_STATIC_DRAW);
   glBindBuffer(GL_ARRAY_BUFFER,vbo);
   prepare_attrib("aPos",3,8*sizeof(float),(void*)0);
}

int main(int argc, char* argv[]){
   //Create a window data type
   SDL_Window* window=nullptr;

   if(SDL_Init(SDL_INIT_VIDEO)<0){
      printf("SDL could not be initialized\n%s",SDL_GetError());
   }else{
      printf("SDL video system is ready to go\n");
   }
   //Before we create our window,specify OpenGL version
   SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION,4);
   SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION,1);
   SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK,SDL_GL_CONTEXT_PROFILE_CORE);
   SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER,1);
   SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE,24);

   window=SDL_CreateWindow("SDL2_OpenGL_Demo",50,50,640,480,SDL_WINDOW_SHOWN | SDL_WINDOW_OPENGL);

   SDL_GLContext context=SDL_GL_CreateContext(window);

   glewExperimental = GL_TRUE;
   glewInit();
   #ifdef __APPLE__
      SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
      SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, SDL_GL_CONTEXT_FORWARD_COMPATIBLE_FLAG);
   #endif
   
   glEnable(GL_DEPTH_TEST);
   prepare_Shader();
   prepare_vao(1,&vao);
   prepare_vbo(1,&vbo,GL_ARRAY_BUFFER,vertices,sizeof(vertices),GL_STATIC_DRAW);
   prepare_attrib("aPos",3,8*sizeof(float),(void*)0);
   prepare_attrib("aUV",2,8*sizeof(float),(void*)(3*sizeof(float)));
   //normal vertex
   prepare_attrib("aNormal",3,8*sizeof(float),(void*)(5*sizeof(float)));
   light_demo();
   prepareTexture();

   PerspectiveCamera camera(90.0f,640.0f/480.0f,0.1f,1000.0f);
   camera.cameraPos=glm::vec3(0.0f,0.0f,3.0f);
   viewMatrix=camera.getViewMatrix();
   perspectiveMatrix=camera.getProjectionMatrix();

   bool gameIsRunning=true;
   while(gameIsRunning){
      glViewport(0,0,640,480);

      SDL_Event event;
      //Start our event loop
      while(SDL_PollEvent(&event)){
         //Handle each specific event
         if(event.type==SDL_QUIT){
            gameIsRunning=false;
         }
      }
      glClearColor(0.5f,0.5f,0.5f,1.0f);
      doRotation();
      render();
      SDL_GL_SwapWindow(window);
   }
   delete texture;

   //延迟3000毫秒
   //SDL_Delay(3000);
   //销毁窗口
   SDL_DestroyWindow(window);

   glDeleteProgram(program);
   //解绑当前vao
   glBindVertexArray(0);
   //销毁VBO
   glDeleteBuffers(1,&vbo);
   //销毁VAO
   glDeleteVertexArrays(1, &vao);
   glDeleteVertexArrays(1, &lightVAO);
   //销毁EBO
   glDeleteBuffers(1,&ebo);
   SDL_Quit();
   return 0;
}